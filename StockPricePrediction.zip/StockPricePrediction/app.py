from flask import Flask, request, jsonify, render_template
import pandas as pd
import numpy as np
import lightgbm as lgb
from tensorflow.keras.models import load_model
import joblib
import logging
import os

# Set up logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__, static_url_path='/static', static_folder='static')

# Define absolute paths for model files
BASE_DIR = "E:\\StockPricePrediction\\StockPricePrediction"
MODEL_DIR = os.path.join(BASE_DIR, "models")
MODEL_FILES = {
    "lgb_model": os.path.join(MODEL_DIR, "lgb_model.txt"),
    "gru_model": os.path.join(MODEL_DIR, "gru_model.keras"),
    "scaler": os.path.join(MODEL_DIR, "scaler.pkl")
}

# Verify and load models with error handling
for model_name, file_path in MODEL_FILES.items():
    if not os.path.exists(file_path):
        logging.error(f"Model file not found: {file_path}")
        raise FileNotFoundError(f"Missing model file: {file_path}")

try:
    logging.debug(f"Loading LightGBM model from {MODEL_FILES['lgb_model']}...")
    lgb_model = lgb.Booster(model_file=MODEL_FILES["lgb_model"])
    logging.debug(f"Loading GRU model from {MODEL_FILES['gru_model']}...")
    gru_model = load_model(MODEL_FILES["gru_model"])
    logging.debug(f"Loading scaler from {MODEL_FILES['scaler']}...")
    scaler = joblib.load(MODEL_FILES["scaler"])
    logging.debug("Models and scaler loaded successfully")
except Exception as e:
    logging.error(f"Error loading models: {e}", exc_info=True)
    raise

@app.route("/")
def home():
    logging.debug("Rendering index.html")
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "No data provided"}), 400

        logging.debug(f"Received data: {data}")

        # Preprocess input on-the-fly
        input_data = pd.DataFrame([{
            "Present_Price": float(data.get("present_price", 0)),
            "Num_Stocks": float(data.get("num_stocks", 0)),
            "Before_Day_Close": float(data.get("before_day_close", 0)),
            "Today_Open": float(data.get("today_open", 0)),
            "Today_Close": float(data.get("today_close", 0)),
            "5_Day_Avg": float(data.get("five_day_avg", 0)),
            "10_Day_Avg": float(data.get("ten_day_avg", 0))
        }])

        logging.debug(f"Processed input data: {input_data}")

        # Validate input data
        if input_data.isnull().any().any():
            return jsonify({"error": "Invalid or missing input values"}), 400

        # LightGBM prediction
        lgb_pred = lgb_model.predict(input_data)[0]
        logging.debug(f"LGB prediction: {lgb_pred}")

        # GRU prediction (adjusted for single input)
        input_scaled = scaler.transform(input_data)
        gru_input = input_scaled.reshape(1, 1, len(input_data.columns))  # (samples, timesteps, features)
        logging.debug(f"GRU input shape: {gru_input.shape}")
        gru_pred = gru_model.predict(gru_input)[0][0]
        logging.debug(f"GRU prediction: {gru_pred}")

        return jsonify({"lgb_prediction": float(lgb_pred), "gru_prediction": float(gru_pred)})

    except ValueError as ve:
        logging.error(f"Value error in prediction: {ve}")
        return jsonify({"error": f"Invalid input data: {str(ve)}"}), 400
    except Exception as e:
        logging.error(f"Prediction error: {e}", exc_info=True)
        return jsonify({"error": f"Server error: {str(e)}"}), 500

if __name__ == "__main__":
    app.run(debug=True)