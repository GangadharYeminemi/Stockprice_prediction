import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
import lightgbm as lgb
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import GRU, Dense, Dropout
from sklearn.preprocessing import MinMaxScaler
import joblib

# Load raw data
df = pd.read_csv(r"E:\StockPricePrediction\StockPricePrediction\data\stock_price_dataset.csv")

# Preprocess on-the-fly
df = df[["Date", "Open", "Close", "Volume", "MA5", "MA10"]]
df["Before_Day_Close"] = df["Close"].shift(1)
df = df.rename(columns={
    "Open": "Today_Open",
    "Close": "Today_Close",
    "Volume": "Num_Stocks",
    "MA5": "5_Day_Avg",
    "MA10": "10_Day_Avg"
})
df["Present_Price"] = df["Today_Close"]
df["Target"] = df["Today_Close"].shift(-1)
df = df.dropna()

# Features and target
features = ["Present_Price", "Num_Stocks", "Before_Day_Close", "Today_Open", 
            "Today_Close", "5_Day_Avg", "10_Day_Avg"]
X = df[features]
y = df["Target"]

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

# LightGBM Model
lgb_train = lgb.Dataset(X_train, y_train)
lgb_test = lgb.Dataset(X_test, y_test)
params = {
    "objective": "regression",
    "metric": "mae",
    "boosting_type": "gbdt",
    "learning_rate": 0.01,
    "num_leaves": 31,
    "max_depth": -1
}
lgb_model = lgb.train(params, lgb_train, num_boost_round=100, valid_sets=[lgb_test])
lgb_model.save_model("models/lgb_model.txt")

# GRU Model (requires scaling and sequences)
scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X)
joblib.dump(scaler, "models/scaler.pkl")

def create_sequences(data, seq_length):
    X_seq, y_seq = [], []
    for i in range(len(data) - seq_length):
        X_seq.append(data[i:i + seq_length])
        y_seq.append(data[i + seq_length, 4])  # Index 4 is Today_Close
    return np.array(X_seq), np.array(y_seq)

seq_length = 10
X_seq, y_seq = create_sequences(X_scaled, seq_length)
X_train_seq, X_test_seq, y_train_seq, y_test_seq = train_test_split(X_seq, y_seq, test_size=0.2, shuffle=False)

gru_model = Sequential([
    GRU(50, return_sequences=True, input_shape=(seq_length, len(features))),
    Dropout(0.2),
    GRU(50),
    Dropout(0.2),
    Dense(1)
])
gru_model.compile(optimizer="adam", loss="mse")
gru_model.fit(X_train_seq, y_train_seq, epochs=20, batch_size=32, validation_data=(X_test_seq, y_test_seq))
gru_model.save("models/gru_model.h5")

print("Models trained and saved!")