document.getElementById('predictionForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const resultDiv = document.getElementById('result');
    resultDiv.classList.remove('show');
    resultDiv.textContent = 'Loading...';

    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData);

    try {
        const response = await fetch('/predict', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        if (!response.ok) throw new Error('Network response was not ok');
        const result = await response.json();
        resultDiv.textContent = `LGB Prediction: ${result.lgb_prediction.toFixed(2)}, GRU Prediction: ${result.gru_prediction.toFixed(2)}`;
        resultDiv.classList.add('show');
    } catch (error) {
        resultDiv.textContent = `Error: ${error.message}`;
        resultDiv.classList.add('show');
    }
});